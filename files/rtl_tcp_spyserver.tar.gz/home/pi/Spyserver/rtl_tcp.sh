#!/bin/bash

HEIGHT=12
WIDTH=30
CHOICE_HEIGHT=3
BACKTITLE="RTL-TCP/SpyServer SDR-Config"
TITLE="Available SDR Devices"
MENU="Choose one of the following options:"

OPTIONS=(1 "SDR RTL_TCP"
         2 "SDR SpyServer"
         3 "SDR Reset")

CHOICE=$(dialog --clear \
                --backtitle "$BACKTITLE" \
                --title "$TITLE" \
                --menu "$MENU" \
                $HEIGHT $WIDTH $CHOICE_HEIGHT \
                "${OPTIONS[@]}" \
                2>&1 >/dev/tty)

clear
case $CHOICE in
        1)
            rtl_tcp -a 127.0.0.1
#Change ip!
            ;;
        2)
            cd /home/pi/Radio/Spyserver
            ./spyserver
            ;;
        3)
            lsusb | sed -n '/R/p'
            echo "Reset usb"
            resetusb /dev/bus/usb/001/006
            echo Reset SDR suc6
            sleep 2
            ;;

esac

