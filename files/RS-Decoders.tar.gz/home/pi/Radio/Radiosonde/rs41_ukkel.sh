#!/bin/bash

rtl_fm -p 0 -g 42.1 -M fm -F9 -s 9K -f403500000 2>/dev/null | sox -t raw -r 9k -e s -b 16 -c 1 - -r 48000 -b 8 -t wav - lowpass 2600 2>/dev/null | ./rs41mod --ecc2 --crc -vx --ptu 2>&1 | tee -a /home/pi/tmp/rs41_ukkel_`date +%Y%m%d%H`Z.txt | ./pos2nmea.pl > /tmp/virtualcom0

exit
