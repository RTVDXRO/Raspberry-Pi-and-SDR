#!/bin/sh

echo "Cleaning up log files.."
if ls /home/pi/Log/*.txt >/dev/null 2>&1;
then 
echo "Remove RS logs"
find /home/pi/Log/ -name "*.txt"
rm /home/pi/Log/* 2> /dev/null
else
echo "No RS log files found"
fi
sleep 1
if ls /home/pi/Log/DxlAPRS/*.log >/dev/null 2>&1;
then
echo "Removing DxlAPRS log files"
find /home/pi/Log/DxlAPRS/ -name "*"
rm /home/pi/Log/DxlAPRS/*
else
echo "No DxlAPRS log files found"
fi
sleep 1
if ls /home/pi/Log/Auto-RX/*.log >/dev/null 2>&1;
then
echo "Removing Auto-RX log files"
find /home/pi/Log/Auto-RX/ -name "*"
rm /home/pi/Log/Auto-RX/*
rm /home/pi/Radio/auto_rx/chasemapper/gfs/* 2> /dev/null
elif ls /home/pi/Radio/auto_rx/chasemapper/gfs/*.dat >/dev/null 2>&1;
then
echo "Removing Auto-RX log files"
rm /home/pi/Radio/auto_rx/chasemapper/gfs/* 2> /dev/null
else
echo "No Auto-RX log files found"
fi

exit
