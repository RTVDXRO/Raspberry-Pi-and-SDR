#!/bin/sh
dmesg | grep ttyUSB0
echo "Switch DFM from binary 2 NMEA mode..."
cd /home/pi/Gps
stty -F /dev/ttyUSB0 speed 9600
echo "Insert sirfbinary2nmea..."
cat sirfbinary2nmea.txt > /dev/ttyUSB0
echo "Done DFM GPS-Mouse working on 4800 Baud :)..."
#echo "Enable GPSD"
#gpsd /dev/ttyUSB0

sleep 1
