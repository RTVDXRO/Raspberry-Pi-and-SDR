#!/bin/bash

sox -t alsa default -t wav - 2>/dev/null | ./dfm09mod --dist -v --ptu --auto 2>&1 | ./pos2aprs.pl RASPI 0 "_Radiosonde" -d -U 127.0.0.1:9002 > /dev/null

exit
