#!/bin/bash

#-----DIALOG MENU-----
DIALOG_CANCEL=1
DIALOG_ESC=255
HEIGHT=14
WIDTH=47
CHOICE_HEIGHT=6

display_result() {
  dialog --title "$1" \
    --no-collapse \
    --msgbox "$result" 0 0
}

while true; do
  exec 3>&1
  selection=$(dialog \
    --title "RS Config" \
    --clear \
    --cancel-label "Exit" \
    --menu "Please select:" $HEIGHT $WIDTH $CHOICE_HEIGHT \
    "1" "Exit" \
    "2" "DFM Raw Output" \
    "3" "RS-41 Sat Output" \
    "4" "RS-41 Raw Output" \
    "5" "Scan detect" \
    "6" "System Info" \
    2>&1 1>&3)
  exit_status=$?
  exec 3>&-
  case $exit_status in
    $DIALOG_CANCEL)
      clear
      echo "Program terminated."
      exit
      ;;
    $DIALOG_ESC)
      clear
      echo "Program aborted." >&2
      exit 1
      ;;
  esac
  case $selection in
    0 )
      clear
      echo "Program terminated."
      ;;
    1)
killall -9 gpsd xfce4-terminal >/dev/null 2>&1;
      ;;
    2)
clear
sox -t alsa default -t wav - 2>/dev/null | ./dfm09dm_dft --ecc -v --ptu --auto -r
            ;;
    3)
clear
sox -t alsa default -t wav - 2>/dev/null | ./rs41dm_dft --sat
            ;;
    4)
clear
sox -t alsa default -t wav - 2>/dev/null | ./rs41dm_dft --ecc2 --crc -vv --ptu
            ;;
    5)
clear
sox -t alsa default -t wav - 2>/dev/null | ./dft_detect -t 8
read -p "Press [Enter] key when ready..."
            ;;
    6)
clear
echo "System Info"
echo
lsusb | grep RTL28
echo
lsusb | sed -n '/2303/p' | sed 's/.*.Inc. //g';dmesg | sed -n '/ttyUSB0/p' | sed 's/.*.now //g'
echo
read -p "Press [Enter] to continu..."
            ;;
esac

done
