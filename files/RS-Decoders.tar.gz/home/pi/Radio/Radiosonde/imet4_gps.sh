#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh --tab -T i-Met4 -e ./imet4.sh
mv /home/pi/tmp/imet* /home/pi/Log
