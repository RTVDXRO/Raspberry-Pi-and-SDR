#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh --tab -T DFM09 -e ./dfm.sh
mv /home/pi/tmp/dfm09* /home/pi/Log
