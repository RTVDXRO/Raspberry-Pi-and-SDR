#!/bin/bash

#-----DIALOG MENU-----
DIALOG_CANCEL=1
DIALOG_ESC=255
HEIGHT=14
WIDTH=47
CHOICE_HEIGHT=4

display_result() {
  dialog --title "$1" \
    --no-collapse \
    --msgbox "$result" 0 0
}

while true; do
  exec 3>&1
  selection=$(dialog \
    --title "Auto-RX Config" \
    --clear \
    --cancel-label "Exit" \
    --menu "Please select:" $HEIGHT $WIDTH $CHOICE_HEIGHT \
    "1" "Exit" \
    "2" "System Info" \
    "3" "Station Config File" \
    "4" "GFS Wind Model Date" \
    2>&1 1>&3)
  exit_status=$?
  exec 3>&-
  case $exit_status in
    $DIALOG_CANCEL)
      clear
      echo "Program terminated."
      exit
      ;;
    $DIALOG_ESC)
      clear
      echo "Program aborted." >&2
      exit 1
      ;;
  esac
  case $selection in
    0 )
      clear
      echo "Program terminated."
      ;;
    1)
      killall -9 rtl_fm sox python auto_rx.sh chasemapper.sh xfce4-terminal
      mv /home/pi/tmp/Auto-RX/* /home/pi/Log/Auto-RX
      ;;
    2)
clear
echo "System Info"
echo
lsusb | sed -n '/R/p' | sed 's/.*.2832 //g'
sed '23!d' station.cfg;sed '27!d' station.cfg
sed '33!d' station.cfg
echo
lsusb | sed -n '/2303/p' | sed 's/.*.Inc. //g';dmesg | sed -n '/ttyUSB0/p' | sed 's/.*.now //g'
echo
sed '72!d' station.cfg
sed '116!d' station.cfg
sed '148!d' station.cfg
echo
read -p "Press [Enter] to continu..."
            ;;
    3 )
      dialog --title "Station Config File:" --textbox station.cfg 0 0
      ;;
    4 )
if [ -e /home/pi/Radio/auto_rx/chasemapper/gfs/dataset.txt ]
then
      dialog --title "GFS Wind Model Date:" --textbox /home/pi/Radio/auto_rx/chasemapper/gfs/dataset.txt 0 0
else
display_result "No GFS Wind Model found"
fi
      ;;

esac

done
