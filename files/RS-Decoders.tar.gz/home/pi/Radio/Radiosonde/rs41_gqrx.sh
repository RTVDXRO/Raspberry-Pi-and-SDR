#!/bin/bash

sox -t alsa default -r 48000 -b 8 -t wav - lowpass 2600 2>/dev/null | ./rs41mod --ecc2 --crc -vx --ptu 2>&1 | tee -a /home/pi/Log/rs41_`date +%Y%m%d%H`Z.txt | ./pos2nmea.pl > /tmp/virtualcom0

exit
