#!/bin/bash

#-----DIALOG MENU-----
DIALOG_CANCEL=1
DIALOG_ESC=255
HEIGHT=16
WIDTH=47
CHOICE_HEIGHT=12

display_result() {
  dialog --title "$1" \
    --no-collapse \
    --msgbox "$result" 0 0
}

while true; do
  exec 3>&1
  selection=$(dialog \
    --title "DxlAPRS SDR-Config" \
    --clear \
    --cancel-label "Exit" \
    --menu "Please select:" $HEIGHT $WIDTH $CHOICE_HEIGHT \
    "1" "Enter Frequency" \
    "2" "Change Frequency List" \
    "3" "Exit" \
    "4" "Beauvechain 402.870MHz" \
    "5" "De Bilt 403.9MHz" \
    "6" "Ukkel 403.5MHz" \
    "7" "Essen 405.3-404.1MHz" \
    "8" "Meppen 404.5-405.1MHz" \
    "9" "DFM Attack" \
    "10" "View Freq Config" \
    "11" "Show User Config" \
    "12" "Show Server Config" \
    2>&1 1>&3)
  exit_status=$?
  exec 3>&-
  case $exit_status in
    $DIALOG_CANCEL)
      clear
      echo "Program terminated."
      exit
      ;;
    $DIALOG_ESC)
      clear
      echo "Program aborted." >&2
      exit 1
      ;;
  esac
  case $selection in
    0 )
      clear
      echo "Program terminated."
      ;;
    1 )
clear
read -p 'Typ in new Frequency (Ex. XXX.XXX): ' uservar
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "###SDR-Frequency User Defined List XXX.XMHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
sed -i "5s/.*/f $uservar 10 0 70 15000   # User Inserted Freq/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
sed -i "1s/.*/###SDR-Frequency User Defined List $uservar MHz###/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
read -p "Add another Frequency? " -n 1 -r
echo  
if [[ $REPLY =~ ^[Yy]$ ]]
then
read -p 'Typ in new Frequency: ' uservar2
sed -i "1s/.*/###SDR-Frequency User Defined List $uservar $uservar2 MHz###/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
sed -i "6s/.*/f $uservar2 10 0 70 15000   # User Inserted Freq-2/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
fi
       ;;
        2)
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "###SDR-Frequency List 402.700 - 405.800MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 402.7 10 0 70 15000   # Idar Oberstein D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 402.870 10 0 70 15000 # Beauvechain B DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 403.5 10 0 70 15000   # Ukkel B RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 403.9 10 0 70 15000   # De Bilt NL RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 403.930 10 0 70 15000 # Julich D RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.1 10 0 70 15000   # Essen D RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.2 10 0 70 15000   # Herstmonceux GB RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.5 10 0 70 15000   # Meppen D RS41 (eerste en derde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.8 10 0 70 15000   # Herstmonceux GB RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.9 10 0 70 15000   # Idar Oberstein D RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.1 10 0 70 15000   # Meppen D RS41 (tweede en vierde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.3 10 0 70 15000   # Essen D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.7 10 0 70 15000   # Bergen D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.8 10 0 70 15000   # Herstmonceux GB RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
pluma /home/pi/Radio/dxlAPRS/config/sdr_config.txt
#read -p "Press [Enter] key when ready..."
      display_result "Frequency List Changed"
      ;;
    3 )
      killall -9 rtl_tcp udpgate4 sondemod sondeudp sdrtst aprsmap xfce4-terminal
      mv /home/pi/tmp/DxlAPRS/aprs* /home/pi/Log/DxlAPRS
      ;;
    4 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Beauvechain 402.870MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 402.870 10 0 70 15000  # Beauvechain B DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      display_result "Beauvechain 402.870MHz"
      ;;
    5 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List De Bilt 403.9MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.9 10 0 70 15000    # De Bilt NL RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "De Bilt 403.9MHz"
      ;;
    6 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Ukkel 403.5MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.5 10 0 70 15000    # Ukkel B RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Ukkel 403.5MHz"
      ;;
    7 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Essen/E2 404.1-405.3MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 404.1 10 0 70 15000    # Essen D RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 405.3 10 0 70 15000    # Essen D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Essen/E2 404.1-405.3MHz"
      ;;
    8 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Meppen 404.5-405.1MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 404.5 10 0 70 15000    # Meppen D RS41 (eerste en derde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 405.1 10 0 70 15000    # Meppen D RS41 (tweede en vierde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Meppen 404.5-405.1MHz"
      ;;
    9 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List DFM Attack 402.7-403.9MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 402.7 10 0 70 15000   # Idar Oberstein D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 402.870 10 0 70 15000 # Idar Oberstein D DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.45 10 0 70 15000  # Idar Oberstein D DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.5 10 0 70 15000   # RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.87 10 0 70 15000  # Idar Oberstein D DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.9 10 0 70 15000   # RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "DFM Attack 402.7-403.9MHz"
      ;;
    10 )
      dialog --title "Frequency Config:" --textbox /home/pi/Radio/dxlAPRS/config/sdr_config.txt 0 0
      ;;
    11 )
      dialog --title "User Config:" --textbox /home/pi/Radio/dxlAPRS/config/user_info.txt 0 0
      ;;
    12 )
      dialog --title "Srv" --textbox /home/pi/Radio/dxlAPRS/config/aprs-is.txt 0 0
      ;;

  esac

done
