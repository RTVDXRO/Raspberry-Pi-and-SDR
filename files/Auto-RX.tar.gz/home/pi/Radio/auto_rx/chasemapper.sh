#!/bin/bash
# Radiosonde Auto-RX Chasemapper Script
echo "Radiosonde Auto-RX Chasemapper Script"
echo
lsusb | sed -n '/2303/p' | sed 's/.*.Inc. //g';dmesg | sed -n '/ttyUSB0/p' | sed 's/.*.now //g'
sleep 2
cd /home/pi/Radio/auto_rx/chasemapper
python horusmapper.py
