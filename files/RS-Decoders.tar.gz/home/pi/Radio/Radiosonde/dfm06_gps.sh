#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh -tab -T DFM06 -e ./dfm06.sh
mv /home/pi/tmp/dfm06* /home/pi/Log
