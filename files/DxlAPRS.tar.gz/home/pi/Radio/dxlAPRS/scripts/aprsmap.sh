#!/bin/bash
## sane checks
if [ ! -d /home/pi/tmp/DxlAPRS ]; then
	mkdir -p /home/pi/tmp/DxlAPRS
fi
cd /home/pi/Radio/dxlAPRS/bin/aprsmap
./aprsmap
