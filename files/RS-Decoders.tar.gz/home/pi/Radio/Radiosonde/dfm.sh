#!/bin/bash

rtl_fm -p 0 -g 42.1 -M fm -F9 -s 15K -f402870000 2>/dev/null | sox -t raw -r 15k -e s -b 16 -c 1 - -r 48000 -b 8 -t wav - lowpass 2600 2>/dev/null | ./dfm09mod --dist -vv --ptu --auto 2>&1 | tee -a /home/pi/tmp/dfm09_`date +%Y%m%d%H`Z.txt | ./pos2nmea.pl > /tmp/virtualcom0

exit
