#!/bin/sh

chmod 755 rs41_idar.sh
xfce4-terminal -T vp -e ./vp.sh --tab -T Idar -e ./rs41_idar.sh
mv /home/pi/tmp/rs41* /home/pi/Log
