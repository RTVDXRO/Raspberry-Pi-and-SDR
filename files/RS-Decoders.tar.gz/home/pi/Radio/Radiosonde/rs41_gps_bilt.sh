#!/bin/sh

chmod 755 rs41_bilt.sh
xfce4-terminal -T vp -e ./vp.sh --tab -T DeBilt -e ./rs41_bilt.sh
mv /home/pi/tmp/rs41* /home/pi/Log
