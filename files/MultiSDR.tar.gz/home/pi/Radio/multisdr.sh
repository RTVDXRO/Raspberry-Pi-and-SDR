#!/bin/bash
# MultiSDR Script

HEIGHT=14
WIDTH=42
CHOICE_HEIGHT=10
TITLE="MultiSDR-Config"
MENU="Choose one of the following options:"

OPTIONS=(1 "HAB RTTY 432.800MHz"
         2 "HAB AX-25 432.500MHz Log"
         3 "RTL_433 433.000MHz"
         4 "C2000-Flex 169.650MHz"
         5 "RTL_TCP/SpyServer"
         6 "DumpVDL2 136.975MHz"
         7 "POCSAG 172.450MHz"
         8 "Retrogram"
         9 "VORTrack"
         10 "Heatmap")
CHOICE=$(dialog --clear \
                --backtitle "$BACKTITLE" \
                --title "$TITLE" \
                --menu "$MENU" \
                $HEIGHT $WIDTH $CHOICE_HEIGHT \
                "${OPTIONS[@]}" \
                2>&1 >/dev/tty)

clear
case $CHOICE in
        1)
            rtl_fm -M usb -p 0 -g 49.6 -f 432800000 -s 48000 - | rtty 48000 1400 75 570 /dev/stdin
            ;;
        2)
            rtl_fm -p -1 -g 49.6 -f 432500000 -s 22050 - | multimon-ng -a AFSK1200 -t raw /dev/stdin 2>&1 | tee /home/pi/tmp/ax25_`date +%Y%m%d%H`.txt
            ;;
        3)
          rtl_433 -G -p 0 -g 49.6 -f 433956000 -f 433948000 -f 434035000 -f 433960000 -f 433972000 -f 433912000 -f 433875000 -f 433920000 -f 433947000 -f 433757000 -H 20 2>&1 | tee /home/pi/tmp/433_`date +%Y%m%d%H`.txt
            ;;
        4)
            rtl_fm -f 169.65M -M fm -s 22050 -p 0 -g 49.6 | multimon-ng -a FLEX -t raw /dev/stdin 2>&1 | tee /home/pi/tmp/C2000_`date +%Y%m%d%H`.txt
            ;;
        5)
            /home/pi/Radio/Spyserver/rtl_tcp.sh
            ;;
        6)
            dumpvdl2 --rtlsdr 0 --gain 49.6 --correction 0 136725000 136775000 136875000 136975000 2>&1 | tee /home/pi/tmp/vdl2_`date +%Y%m%d%H`.txt
            ;;
        7)
           rtl_fm -p 0 -g 49.6 -f 172.45M -s 22050 - | multimon-ng -a POCSAG1200 -t raw /dev/stdin 2>&1 | tee /home/pi/tmp/POCSAG_`date +%Y%m%d%H`.txt 
            ;;
        8)
            retrogram --rate 1.4e6 --freq 403.5e6 --step 1e5 --gain 49
            ;;
        9)
            vortrack -p 0 -g 49.6 109.25
            ;;

        10)
            read -p 'Typ in duration of record like 60m or 1h ' uservar
            rtl_power -f 400M:450M:8k -p 0 -g 49.6 -i 10 -e $uservar -d 0 > /home/pi/tmp/$(date +%Y-%m-%d_%H-%M)_400-450MHz_8k.csv
            gopow -i /home/pi/tmp/*.csv
            rm /home/pi/tmp/*.csv
            ;;

esac

exit
