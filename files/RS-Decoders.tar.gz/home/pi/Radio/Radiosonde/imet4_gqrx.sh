#!/bin/bash

sox -t alsa default -r 48000 -b 8 -t wav - lowpass 2600 2>/dev/null | ./imet1rsb 2>&1 | tee -a /home/pi/Log/imet4_`date +%Y%m%d%H`Z.txt | ./pos2nmea.pl > /tmp/virtualcom0

exit
