#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh --tab -T M10 -e ./m10.sh
mv /home/pi/tmp/m10* /home/pi/Log
