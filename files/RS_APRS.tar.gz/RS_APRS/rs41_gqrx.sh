#!/bin/bash

sox -t alsa default -t wav - 2>/dev/null | ./rs41mod --ecc2 --crc -vx --ptu 2>&1 | ./pos2aprs.pl RASPI 0 "_Radiosonde" -d -U 127.0.0.1:9002 > /dev/null

exit
