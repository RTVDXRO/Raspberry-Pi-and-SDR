#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh --tab -T Meppen2 -e ./rs41_meppen2.sh
mv /home/pi/tmp/rs41* /home/pi/Log
