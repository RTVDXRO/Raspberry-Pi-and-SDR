#!/bin/bash
url=ftp://cddis.gsfc.nasa.gov/gps/data/daily/$(date +%Y)/brdc/brdc$(date +%j)'0.'$(date +%y)n.Z
if [[ $(wget $url -O-) ]] 2>/dev/null
then
wget $url
gzip -f -d brdc$(date +%j)'0.'$(date +%y)n.Z
mv -f brdc$(date +%j)'0.'$(date +%y)n /home/pi/tmp/DxlAPRS/rinex.txt
fi
