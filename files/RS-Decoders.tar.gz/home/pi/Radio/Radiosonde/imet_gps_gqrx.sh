#!/bin/sh

xfce4-terminal -T Gqrx -e gqrx --tab -T vp -e ./vp.sh -tab -T i-Met -e ./imet_gqrx.sh
mv /home/pi/tmp/imet* /home/pi/Log
