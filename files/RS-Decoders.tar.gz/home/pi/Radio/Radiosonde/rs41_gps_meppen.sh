#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh -tab -T Meppen1 -e ./rs41_meppen.sh
mv /home/pi/tmp/rs41* /home/pi/Log
