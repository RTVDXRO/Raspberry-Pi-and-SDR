#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh --tab -T M20 -e ./m20.sh
mv /home/pi/tmp/m20* /home/pi/Log
