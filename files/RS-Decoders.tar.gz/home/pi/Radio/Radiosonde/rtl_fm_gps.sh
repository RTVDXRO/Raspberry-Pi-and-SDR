#!/bin/bash

HEIGHT=18
WIDTH=40
CHOICE_HEIGHT=10
BACKTITLE="RTL-FM SDR-Config"
TITLE="Available RadioSonde's"
MENU="Choose one of the following options:"

OPTIONS=(1 "Beauvechain B DFM-09"
         2 "Ukkel B RS41 o3"
         3 "De Bilt NL RS41"
         4 "Essen D RS41"
         5 "Julich D RS41 o3"
         6 "Meppen D RS41 (1/3)"
         7 "Herstmonceux GB RS41"
         8 "Meppen D RS41 (2/4)"
         9 "Essen Er D RS41"
         10 "Idar Oberstein D RS41")

CHOICE=$(dialog --clear \
                --backtitle "$BACKTITLE" \
                --title "$TITLE" \
                --menu "$MENU" \
                $HEIGHT $WIDTH $CHOICE_HEIGHT \
                "${OPTIONS[@]}" \
                2>&1 >/dev/tty)

clear
case $CHOICE in
1)
/home/pi/Radio/Radiosonde/dfm.sh
exit
;;
2)
/home/pi/Radio/Radiosonde/rs41_gps_ukkel.sh
exit
;;
3)
/home/pi/Radio/Radiosonde/rs41_gps_bilt.sh
exit
;;
4)
/home/pi/Radio/Radiosonde/rs41_gps_essen.sh
exit
;;
5)
/home/pi/Radio/Radiosonde/rs41_gps_julich.sh
exit
;;
6)
/home/pi/Radio/Radiosonde/rs41_gps_meppen.sh
exit
 ;;
7)
/home/pi/Radio/Radiosonde/rs41_gps_herst.sh
exit
;;
8)
/home/pi/Radio/Radiosonde/rs41_gps_meppen2.sh
exit
;;
9)
/home/pi/Radio/Radiosonde/rs41_gps_essen2.sh
exit
;;
10)
/home/pi/Radio/Radiosonde/rs41_gps_idar.sh
exit
;;
esac

