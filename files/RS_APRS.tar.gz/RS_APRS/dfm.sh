#!/bin/bash

rtl_fm -p 0 -g 49.6 -M fm -F9 -s 15K -f402870000 2>/dev/null | sox -t raw -r 15k -e s -b 16 -c 1 - -r 48000 -b 8 -t wav - lowpass 2600 2>/dev/null | ./dfm09mod --dist -v --ptu --auto 2>&1 | ./pos2aprs.pl RASPI 0 "_Radiosonde" -d -U 127.0.0.1:9002 > /dev/null

exit
