#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh --tab -T i-Met -e ./imet.sh
mv /home/pi/tmp/imet* /home/pi/Log
