#!/bin/sh

chmod 755 rs41_essen.sh
xfce4-terminal -T vp -e ./vp.sh --tab -T Essen -e ./rs41_essen.sh
mv /home/pi/tmp/rs41* /home/pi/Log
