#!/bin/sh

chmod 755 rs41_julich.sh
xfce4-terminal -T vp -e ./vp.sh --tab -T Julich -e ./rs41_julich.sh
mv /home/pi/tmp/rs41* /home/pi/Log
