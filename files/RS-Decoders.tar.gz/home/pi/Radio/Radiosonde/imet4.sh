#!/bin/bash

rtl_fm -p 0 -g 42.1 -M fm -F9 -s 15K -f402997000 2>/dev/null | sox -t raw -r 15k -e s -b 16 -c 1 - -r 48000 -b 8 -t wav - highpass 20 2>/dev/null | ./imet1rs_dft 2>&1 | tee -a /home/pi/tmp/imet4_`date +%Y%m%d%H`Z.txt | ./pos2nmea.pl > /tmp/virtualcom0

exit
