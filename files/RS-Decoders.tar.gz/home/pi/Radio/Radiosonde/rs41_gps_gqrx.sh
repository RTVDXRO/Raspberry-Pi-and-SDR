#!/bin/sh

xfce4-terminal -T Gqrx -e gqrx --tab -T vp -e ./vp.sh --tab -T Menu -e ./menu.sh --tab -T RS41 -e ./rs41_gqrx.sh
mv /home/pi/tmp/rs41* /home/pi/Log
