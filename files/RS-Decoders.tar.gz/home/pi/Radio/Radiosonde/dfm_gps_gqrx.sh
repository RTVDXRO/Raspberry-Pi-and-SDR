#!/bin/sh

xfce4-terminal -T Gqrx -e gqrx --tab -T vp -e ./vp.sh -tab -T Menu -e ./menu.sh --tab -T DFM09 -e ./dfm_gqrx.sh
mv /home/pi/tmp/dfm09* /home/pi/Log
