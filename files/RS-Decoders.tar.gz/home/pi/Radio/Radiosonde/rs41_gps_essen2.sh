#!/bin/sh

xfce4-terminal -T vp -e ./vp.sh --tab -T Essen2 -e ./rs41_essen2.sh
mv /home/pi/tmp/rs41* /home/pi/Log
