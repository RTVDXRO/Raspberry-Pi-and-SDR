#!/bin/bash

#sane checks
if [ ! -d /home/pi/tmp/DxlAPRS ]; then
	mkdir -p /home/pi/tmp/DxlAPRS
fi

sed -i '36s/.*/Connect Server|1|/' /home/pi/Radio/dxlAPRS/bin/aprsmap/aprsmap.cfg

echo "DxlAPRS Config"
echo
sed '1!d' /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo 
echo -n "Connected to APRS-Server: ";sed '1!d' /home/pi/Radio/dxlAPRS/config/aprs-is.txt
echo
lsusb | sed -n '/R/p' | sed 's/.*.2832 //g' 
echo -n "PPM: ";sed '12!d' /home/pi/Radio/dxlAPRS/config/user_info.txt
echo -n "Gain: ";sed '14!d' /home/pi/Radio/dxlAPRS/config/user_info.txt
echo
lsusb | sed -n '/2303/p' | sed 's/.*.Inc. //g';dmesg | sed -n '/ttyUSB0/p' | sed 's/.*.now //g'
echo ""
read -p "Press [Enter] to continu..."
#-----DIALOG MENU-----
DIALOG_CANCEL=1
DIALOG_ESC=255
HEIGHT=16
WIDTH=47
CHOICE_HEIGHT=19

display_result() {
  dialog --title "$1" \
    --no-collapse \
    --msgbox "$result" 0 0
}

while true; do
  exec 3>&1
  selection=$(dialog \
    --title "DxlAPRS SDR-Config" \
    --clear \
    --cancel-label "Exit" \
    --menu "Please select:" $HEIGHT $WIDTH $CHOICE_HEIGHT \
    "1" "Start DxlAPRS" \
    "2" "Enter Frequency" \
    "3" "Change Frequency List" \
    "4" "Exit" \
    "5" "Beauvechain 402.870MHz" \
    "6" "Ukkel 403.5MHz" \
    "7" "De Bilt 403.9MHz" \
    "8" "Essen 404.1-405.3MHz" \
    "8" "Meppen 404.5-405.1MHz" \
    "10" "Herstmonceux 404.2-404.8MHz" \
    "11" "Ukkel, Julich, De Bilt, Essen" \
    "12" "DFM Attack" \
    "13" "View Freq Config" \
    "14" "Show User Config" \
    "15" "Show Server Config" \
    "16" "Local APRS Server" \
    "17" "Radiosondy APRS Server" \
    "18" "Enter PPM" \
    "19" "Enter Gain" \
    2>&1 1>&3)
  exit_status=$?
  exec 3>&-
  case $exit_status in
    $DIALOG_CANCEL)
      clear
      echo "Program terminated."
      exit
      ;;
    $DIALOG_ESC)
      clear
      echo "Program aborted." >&2
      exit 1
      ;;
  esac
  case $selection in
    0 )
      clear
      echo "Program terminated."
      ;;
    1 )
IPADDR=127.0.0.1
#-----USER CONFIGURATION-----
CALLSIGN=$(sed -n 2p /home/pi/Radio/dxlAPRS/config/user_info.txt)
LAT=$(sed -n 4p /home/pi/Radio/dxlAPRS/config/user_info.txt)
LON=$(sed -n 6p /home/pi/Radio/dxlAPRS/config/user_info.txt)
GATE_INFO=$(sed -n 8p /home/pi/Radio/dxlAPRS/config/user_info.txt)
FRAME_COMMENT=$(sed -n 10p /home/pi/Radio/dxlAPRS/config/user_info.txt)
#-----AUTH SETTINGS-----
LOG_FORMAT=$(date +"%Y_%m_%d_%H_%M_%S")
PASSWORD=$(python /home/pi/Radio/dxlAPRS/scripts/aprs_passcode.py ${CALLSIGN})
APRS_FILTER="\m/9000"
#-----RTL-TCP SETTINGS-----
RTLPORT=1234
GAIN=$(sed -n 14p /home/pi/Radio/dxlAPRS/config/user_info.txt)
PPM=$(sed -n 12p /home/pi/Radio/dxlAPRS/config/user_info.txt)
DEVICE=0
#BLOCKSIZE=20
#-----FILES SETTINGS-----
## sane checks
if [ ! -d /home/pi/tmp/DxlAPRS ]; then
	mkdir -p /home/pi/tmp/DxlAPRS
fi
RINEX_FILE=/home/pi/tmp/DxlAPRS/rinex.txt
RAW_AUDIO=/home/pi/tmp/DxlAPRS/audio_buffer.fifo
BEACON_FILE=/home/pi/Radio/dxlAPRS/config/station_beacon.txt
FRAME_FILE=/home/pi/Radio/dxlAPRS/config/frame_comment.txt
APRS_SERVERS=/home/pi/Radio/dxlAPRS/config/aprs-is.txt
GATE_LOGFILE=/home/pi/Radio/dxlAPRS/log/aprs-is.log
SDRTST_CONFIG=/home/pi/Radio/dxlAPRS/config/sdr_config.txt
#-----PORT SETTINGS-----
SONDEMOD_PORT=4000
UDPGATE_PORT=9001
UDPGATE_AUX_PORT=4010
UDPGATE_AUX=4011
UDPGATE_APRS_PORT=14580
UDPGATE_RF_PORT=14581
#-----SONDEUDP SETTINGS-----
MAXCHANNELS=0
BUFLEN=128
ADCRATE=25000
SONDE_GATE=${IPADDR}":"${SONDEMOD_PORT}
#-----UDPGATE4 SETTINGS-----
GATER=${IPADDR}":"${UDPGATE_AUX}":"${UDPGATE_AUX_PORT}
GATE_CALLSIGN="${CALLSIGN}-12"
UDP_RF="${IPADDR}:${UDPGATE_RF_PORT}:${UDPGATE_PORT}"
BEACON_INFO="!${LAT}N/${LON}E\`${GATE_INFO}"
BEACON_INTERVAL=30
echo "${BEACON_INFO}" >${BEACON_FILE}
echo "${FRAME_COMMENT}" >${FRAME_FILE}
#-----SONDEMOD SETTINGS-----
GATE_ADDRESS=${IPADDR}:${UDPGATE_AUX_PORT}
SENDER_CALLSIGN="${CALLSIGN}-13"
REQUEST_NEW_ALMANACH=30
LOWER_ALTITUDE=$(sed -n 20p /home/pi/Radio/dxlAPRS/config/user_info.txt)
LOWER_ALTITUDE_INTERVAL=$(sed -n 18p /home/pi/Radio/dxlAPRS/config/user_info.txt)
HIGH_ALTITUDE_INTERVAL=$(sed -n 16p /home/pi/Radio/dxlAPRS/config/user_info.txt)
SEND_TYPE=2 #0- if weather data ready 1- if MHz known 2- send immediately
#-----START COMMANDS------
RTLSDR_RUN="rtl_tcp \
-d ${DEVICE} \
-a ${IPADDR} \
-p ${RTLPORT} \
-g ${GAIN} \
#-b ${BLOCKSIZE} \
-P ${PPM} \
-n 1 \
"
SDRTST_RUN="/home/pi/Radio/dxlAPRS/bin/sdrtst \
-c ${SDRTST_CONFIG} \
-t ${IPADDR}:${RTLPORT} \
-r ${ADCRATE} \
-k \
-v \
-s ${RAW_AUDIO} \
"
SONDEUDP_RUN="/home/pi/Radio/dxlAPRS/bin/sondeudp \
-f ${ADCRATE} \
-l ${BUFLEN} \
-c ${MAXCHANNELS} \
-o ${RAW_AUDIO} \
-I ${SENDER_CALLSIGN} \
-v \
-N 172 \
-u ${IPADDR}":"${SONDEMOD_PORT} \
"
UDPGATE4_RUN="/home/pi/Radio/dxlAPRS/bin/udpgate4 \
-v \
-R ${GATER} \
-M ${UDP_RF} \
-s ${GATE_CALLSIGN} \
-f ${APRS_FILTER} \
-n ${BEACON_INTERVAL}:${BEACON_FILE} \
-l 7:${GATE_LOGFILE} \
-t ${UDPGATE_APRS_PORT} \
-g :${APRS_SERVERS} \
-p ${PASSWORD} \
-w 14501 \
-D /home/pi/Radio/dxlAPRS/dxlAPRS_common/www/ \
"
SONDEMOD_RUN="/home/pi/Radio/dxlAPRS/bin/sondemod \
-v \
-x ${RINEX_FILE} \
-r ${GATE_ADDRESS} \
-o ${SONDEMOD_PORT} \
-I ${SENDER_CALLSIGN} \
-R ${REQUEST_NEW_ALMANACH} \
-T 1440 \
-d \
-A ${LOWER_ALTITUDE} \
-B ${LOWER_ALTITUDE_INTERVAL} \
-b ${HIGH_ALTITUDE_INTERVAL} \
-p ${SEND_TYPE} \
-t ${FRAME_FILE} \
-N 92 \
-P JO20XW31 \
-S /home/pi -L AC=DFM09,70=DFM17 \
"

#-----STARTING DECODER-----
rm -f ${RAW_AUDIO} 2> /dev/null
mkfifo ${RAW_AUDIO}
sudo -S killall -9 gpsd 2> /dev/null
sleep 1
xfce4-terminal -T SDRcfg -e /home/pi/Radio/dxlAPRS/scripts/sdrcfg.sh --tab -T GPS2APRS -e /home/pi/Radio/dxlAPRS/scripts/gps.sh --tab -T aprsmap -e /home/pi/Radio/dxlAPRS/scripts/aprsmap.sh --tab -T RTL_TCP0 -e $"${RTLSDR_RUN}" --tab -T SDRtst -e $"${SDRTST_RUN}" --tab -T Sondeudp -e $"${SONDEUDP_RUN}" --tab -T Udpgate4 -e $"${UDPGATE4_RUN}" --tab -T Sondemod -e $"${SONDEMOD_RUN}"
exit
      ;;
    2 )
clear
read -p 'Typ in new Frequency (like xxx.xxx): ' uservar
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "###SDR-Frequency User Defined List XXX.XMHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
sed -i "5s/.*/f $uservar 10 0 70 15000   # User Inserted Freq/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
sed -i "1s/.*/###SDR-Frequency User Defined List $uservar MHz###/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
read -p "Add another Frequency? " -n 1 -r
echo  
if [[ $REPLY =~ ^[Yy]$ ]]
then
read -p 'Typ in new Frequency (Ex. XXX.XXX): ' uservar2
sed -i "1s/.*/###SDR-Frequency User Defined List $uservar $uservar2 MHz###/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
sed -i "6s/.*/f $uservar2 10 0 70 15000   # User Inserted Freq-2/" /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
fi
            ;;
        3)
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "###SDR-Frequency List 402.700 - 405.800MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 402.7 10 0 70 15000   # Idar Oberstein D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 402.870 10 0 70 15000 # Beauvechain B DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 403.5 10 0 70 15000   # Ukkel B RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 403.9 10 0 70 15000   # De Bilt NL RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 403.930 10 0 70 15000 # Julich D RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.1 10 0 70 15000   # Essen D RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.2 10 0 70 15000   # Herstmonceux GB RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.5 10 0 70 15000   # Meppen D RS41 (eerste en derde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.8 10 0 70 15000   # Herstmonceux GB RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 404.9 10 0 70 15000   # Idar Oberstein D RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.1 10 0 70 15000   # Meppen D RS41 (tweede en vierde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.3 10 0 70 15000   # Essen D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.7 10 0 70 15000   # Bergen D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.8 10 0 70 15000   # Herstmonceux GB RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
pluma /home/pi/Radio/dxlAPRS/config/sdr_config.txt
read -p "Press [Enter] key when ready..."
            ;;
    4 )
      echo radiosonde | sudo -S killall -9 dxlaprs.sh
      ;;
    5 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Beauvechain 402.870MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 402.870 10 0 70 15000  # Beauvechain B DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Beauvechain 402.870MHz"
      ;;
    6 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Ukkel 403.5MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.5 10 0 70 15000    # Ukkel B RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Ukkel 403.5MHz"
      ;;
    7 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List De Bilt 403.9MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.9 10 0 70 15000    # De Bilt NL RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "De Bilt 403.9MHz"
      ;;
    8 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Essen 404.1-405.3MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 404.1 10 0 70 15000    # Essen D RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#f 405.1 10 0 70 15000   # Meppen D RS41 (tweede en vierde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 405.3 10 0 70 15000    # Essen D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Essen 404.1-405.3MHz"
      ;;
    9 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Meppen 404.5-405.1MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 404.5 10 0 70 15000    # Meppen D RS41 (eerste en derde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 405.1 10 0 70 15000    # Meppen D RS41 (tweede en vierde sondering)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Meppen 404.5-405.1MHz"
      ;;
    10 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Herstmonceux 404.8-405.8MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 404.2 10 0 70 15000    # Herstmonceux GB RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 404.8 10 0 70 15000    # Herstmonceux GB RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 405.8 10 0 70 15000    # Herstmonceux GB RS41 Ersatzfrequenz" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Herstmonceux 404.8-405.8MHz"
      ;;
    11 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List Ukkel/Jul/Db/Es 403.5-405.3MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.5 10 0 70 15000    # Ukkel B RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.9 10 0 70 15000    # De Bilt NL RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.930 10 0 70 15000  # Julich D RS41 o3" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 405.3 10 0 70 15000    # Essen D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "Ukkel/Jul/Db/Es 403.5-405.3MHz"
      ;;
    12 )
rm /home/pi/Radio/dxlAPRS/config/sdr_config.txt
      result=$(echo "###SDR-Frequency List DFM Attack 402.7-403.9MHz###" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "# f=Frequenz AFC=10 Squelch(0=off<->100=on) Lowpassfilter=70 IF-width(9000 12000 15000Hz)" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 402.7 10 0 70 15000   # Idar Oberstein D RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 402.870 10 0 70 15000 # Idar Oberstein D DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.45 10 0 70 15000  # Idar Oberstein D DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.5 10 0 70 15000   # RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.87 10 0 70 15000  # Idar Oberstein D DFM-09" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "f 403.9 10 0 70 15000   # RS41" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt
echo "#-----------------------------------------------------------------------------------------------------" >> /home/pi/Radio/dxlAPRS/config/sdr_config.txt)
      display_result "DFM Attack"
      ;;
    13 )
      dialog --title "Frequency Config:" --textbox /home/pi/Radio/dxlAPRS/config/sdr_config.txt 0 0
      ;;
    14 )
      dialog --title "User Config:" --textbox /home/pi/Radio/dxlAPRS/config/user_info.txt 0 0
      ;;
    15 )
      dialog --title "Srv" --textbox /home/pi/Radio/dxlAPRS/config/aprs-is.txt 0 0
      ;;
    16)
      sed -i '1s/.*/127.0.0.1:14580/' /home/pi/Radio/dxlAPRS/config/aprs-is.txt
      sed -i '16s/.*/5/' /home/pi/Radio/dxlAPRS/config/user_info.txt
      sed -i '18s/.*/5/' /home/pi/Radio/dxlAPRS/config/user_info.txt
      display_result "aprs_enabled_server 127.0.0.1"
      ;;
    17)
      sed -i '1s/.*/radiosondy.info:14590/' /home/pi/Radio/dxlAPRS/config/aprs-is.txt
      sed -i '16s/.*/10/' /home/pi/Radio/dxlAPRS/config/user_info.txt
      sed -i '18s/.*/10/' /home/pi/Radio/dxlAPRS/config/user_info.txt
      display_result "aprs_enabled_server = radiosondy.info"
      ;;
    18)clear
echo "Current used PPM:" 
sed '12!d' /home/pi/Radio/dxlAPRS/config/user_info.txt
echo
read -p 'Typ in new PPM Value: ' uservar
sed -i "12s/.*/$uservar/" /home/pi/Radio/dxlAPRS/config/user_info.txt
display_result "PPM set to: $uservar"
            ;;
    19)clear
echo "Current used Gain:" 
sed '14!d' /home/pi/Radio/dxlAPRS/config/user_info.txt
echo
read -p 'Typ in new Gain Value (0=auto max=49.6): ' uservar
sed -i "14s/.*/$uservar/" /home/pi/Radio/dxlAPRS/config/user_info.txt
display_result "Gain set: $uservar"
            ;;
  esac

done
