#!/bin/bash

killall gpsd  >/dev/null 2>&1;
sleep 1
cd /home/pi/Radio/dxlAPRS/bin
./gps2aprs -t /dev/ttyUSB0:4800 -I CAR -i /k -D -0 30 -b 2 -v -r 127.0.0.1:9002
