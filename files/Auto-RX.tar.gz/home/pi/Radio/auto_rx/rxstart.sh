#!/bin/bash
# Radiosonde Auto-RX Script

## sane checks
if [ ! -d /home/pi/tmp/Auto-RX ]; then
	mkdir -p /home/pi/tmp/Auto-RX
fi

echo "Auto-RX Server-Config"
echo
lsusb | sed -n '/R/p' | sed 's/.*.2832 //g'
sed '23!d' station.cfg;sed '27!d' station.cfg
sed '33!d' station.cfg
echo
lsusb | sed -n '/2303/p' | sed 's/.*.Inc. //g';dmesg | sed -n '/ttyUSB0/p' | sed 's/.*.now //g'
echo
sed '72!d' station.cfg
sed '116!d' station.cfg
sed '148!d' station.cfg
echo
read -p "Press [Enter] to continu..."
#-----DIALOG MENU-----
DIALOG_CANCEL=1
DIALOG_ESC=255
HEIGHT=16
WIDTH=47
CHOICE_HEIGHT=19

display_result() {
  dialog --title "$1" \
    --no-collapse \
    --msgbox "$result" 0 0
}

while true; do
  exec 3>&1
  selection=$(dialog \
    --title "DxlAPRS SDR-Config" \
    --clear \
    --cancel-label "Exit" \
    --menu "Please select:" $HEIGHT $WIDTH $CHOICE_HEIGHT \
    "1" "Start Auto-RX" \
    "2" "Enter Frequency" \
    "3" "All Frequency List" \
    "4" "Exit" \
    "5" "Beauvechain 402.870MHz" \
    "6" "Ukkel 403.500MHz" \
    "7" "De Bilt 403.900MHz" \
    "8" "Julich 403.930MHz" \
    "9" "Essen 405.300MHz" \
    "10" "Meppen 404.500MHz" \
    "11" "Meppen 405.100MHz" \
    "12" "Essen Er 404.100MHz" \
    "13" "Herstmonceux 404.800MHz" \
    "14" "No Upload to Habhub" \
    "15" "Upload to Habhub" \
    "16" "No APRS Upload" \
    "17" "Radiosondy APRS Server" \
    "18" "Enter PPM" \
    "19" "Enter Gain" \
    2>&1 1>&3)
  exit_status=$?
  exec 3>&-
  case $exit_status in
    $DIALOG_CANCEL)
      clear
      echo "Program terminated."
      exit
      ;;
    $DIALOG_ESC)
      clear
      echo "Program aborted." >&2
      exit 1
      ;;
  esac
  case $selection in
    0 )
      clear
      echo "Program terminated."
      ;;
    1 )
      rm -rf /home/pi/Maps/maps4free 2> /dev/null
rm -rf /home/pi/Maps/mobile 2> /dev/null
rm -rf /home/pi/Maps/OSM 2> /dev/null
rm -rf /home/pi/Maps/outdoors 2> /dev/null

xfce4-terminal -T Menu -e ./menu.sh --tab -T ChaseMapper -e ./chasemapper.sh --tab -T Auto-RX -e ./auto_rx.sh
exit
      ;;
    2 )
clear
read -p 'Typ in new Frequency (like xxx.xxx): ' uservar
sed -i "72s/.*/whitelist = [$uservar]/" station.cfg
            ;;
        3)
            result=$(sed -i '72s/.*/whitelist = [402.700, 402.870, 403.500, 403.900, 403.930, 404.100, 404.500, 404.800, 404.900, 405.100, 405.300, 405.700, 405.800]/' station.cfg)
      display_result "All Frequency List"
            ;;
    4 )
      sudo -S killall -9 rxstart.sh
      ;;
    5 )
      result=$(sed -i '72s/.*/whitelist = [402.870]/' station.cfg
            sed -i '91s/.*/default_burst = 28000/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 12.5/' chasemapper/horusmapper.cfg)
      display_result "Beauvechain 402.870MHz"
      ;;
    6 )
      result=$(sed -i '72s/.*/whitelist = [403.500]/' station.cfg
            sed -i '91s/.*/default_burst = 35000/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 5.0/' chasemapper/horusmapper.cfg)
      display_result "Ukkel 403.500MHz"
      ;;
    7 )
      result=$(sed -i '72s/.*/whitelist = [403.900]/' station.cfg
            sed -i '91s/.*/default_burst = 34000/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 4.8/' chasemapper/horusmapper.cfg)
      display_result "De Bilt 403.900MHz"
      ;;
    8 )
      result=$(sed -i '72s/.*/whitelist = [403.930]/' station.cfg
            sed -i '91s/.*/default_burst = 25000/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 5.0/' chasemapper/horusmapper.cfg)
      display_result "Julich-403.930MHz"
      ;;
    9 )
      result=$(sed -i '72s/.*/whitelist = [405.300]/' station.cfg
            sed -i '91s/.*/default_burst = 34000/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 4.5/' chasemapper/horusmapper.cfg)
      display_result "Essen 405.300MHz"
      ;;
    10 )
      result=$(sed -i '72s/.*/whitelist = [404.500]/' station.cfg
            sed -i '91s/.*/default_burst = 21750/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 2.5/' chasemapper/horusmapper.cfg)
      display_result "Meppen 404.500MHz"
      ;;
    11 )
      result=$(sed -i '72s/.*/whitelist = [405.100]/' station.cfg
            sed -i '91s/.*/default_burst = 21750/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 2.5/' chasemapper/horusmapper.cfg)
      display_result "Meppen 405.100MHz"
      ;;
    12 )
      result=$(sed -i '72s/.*/whitelist = [405.100]/' station.cfg
            sed -i '91s/.*/default_burst = 34000/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 4.5/' chasemapper/horusmapper.cfg)
      display_result "Essen Er 405.100MHz"
      ;;
    13 )
      result=$(sed -i '72s/.*/whitelist = [404.800]/' station.cfg
            sed -i '91s/.*/default_burst = 27000/' chasemapper/horusmapper.cfg
            sed -i '92s/.*/default_descent_rate = 4.0/' chasemapper/horusmapper.cfg)
      display_result "Herstmonceux 404.800MHz"
      ;;
        14)
sed -i '116s/.*/habitat_enabled = False/' station.cfg
display_result "habitat_enabled = False"
            ;;
        15)
sed -i '116s/.*/habitat_enabled = True/' station.cfg
display_result "habitat_enabled = True"
            ;;
        16)
sed -i '148s/.*/aprs_enabled = False/' station.cfg
display_result "aprs_enabled = False"
            ;;
        17)
sed -i '148s/.*/aprs_enabled = True/' station.cfg
sed -i '162s/.*/aprs_server = radiosondy.info/' station.cfg
display_result "aprs_enabled_server = radiosondy.info"
            ;;
        18)clear
echo "Current used PPM:" 
sed '27!d' /home/pi/Radio/auto_rx/station.cfg
echo
read -p 'Typ in new PPM Value: ' uservar
sed -i "27s/.*/ppm = $uservar/" /home/pi/Radio/auto_rx/station.cfg
display_result "PPM set: $uservar"
            ;;
    19)clear
echo "Current used Gain:" 
sed '33!d' /home/pi/Radio/auto_rx/station.cfg
echo
read -p 'Typ in new Gain Value (-1=auto max=49.6): ' uservar
sed -i "33s/.*/gain = $uservar/" /home/pi/Radio/auto_rx/station.cfg
display_result "Gain set: $uservar"
            ;;
  esac

done
