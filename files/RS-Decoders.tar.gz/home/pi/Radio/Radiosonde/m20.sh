#!/bin/bash

rtl_fm -p 0 -M fm -F9 -s 22K -f401400000 2>/dev/null | sox -t raw -r 22k -e s -b 16 -c 1 - -r 48000 -b 8 -t wav - highpass 20 2>/dev/null | ./mXXmod -vv --br 9603 2>&1 | tee -a /home/pi/tmp/m20_`date +%Y%m%d%H`Z.txt | ./pos2nmea.pl > /tmp/virtualcom0

exit
