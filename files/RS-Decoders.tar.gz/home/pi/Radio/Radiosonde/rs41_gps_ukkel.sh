#!/bin/sh

chmod 755 rs41_ukkel.sh
xfce4-terminal -T vp -e ./vp.sh --tab -T Ukkel-o3 -e ./rs41_ukkel.sh
mv /home/pi/tmp/rs41* /home/pi/Log
